/* 
 * File:   main.cpp
 * Author: Juan M. Rodriguez
 * Created on October 5, 2017, 11:27 AM
 * Purpose: Soylent Green 
 */

//System Libraries Here
#include <iostream>
#include <iomanip> //Format
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int fi,fim1,fim2,counter;
    int wtCrud=10;//5lbs of curd to start
    int deltDys=5;//5 days between increments
    //Input or initialize values Here
    fim1=fim2=1;//Initializes the sequence 
    counter=1;  //Start with 3rd term in the sequence 
    
    //Table Header
    cout<<"  Sequence  Crud Wt   N Days"<<endl;
    
    
    
    //Process/Calculations Here
    //First row
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim2
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //second row
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim1
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //third row
    fi=fim1+fim2;
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
            
    //fourth row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    //nth row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
     //nth row
     fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
            <<setw(10)<<(counter-1)*deltDys<<endl;
    //Output Located Here
    

    //Exit
    return 0;
}

