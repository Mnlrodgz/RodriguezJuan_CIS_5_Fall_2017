/* 
 * File:   main.cpp
 * Author: Juan M. Rodriguez
 * Created on October 3, 2017, 11:26 AM
 * Purpose: Display which runner came in first, second, and third 
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float weight,//Weight of the object.
    mass;//mass of the object
  
    
    //Input or initialize values Here

    
    
    //Process/Calculations Here
    weight= mass*9.8;
    
    
    //Output Located Here
    cout<<"Enter the mass of the object"<<endl;
    cin>>mass;
    cout<<"The weight of the object ="<<mass*9.8<<endl;
    if (weight>1000)
        cout<<"The weight of the object is too much"<<endl;
    
    
    
    

    //Exit
    return 0;
}

