/* 
 * File:   main.cpp
 * Author: Juan M. Rodriguez
 * Created on October 3, 2017, 11:10 AM
 * Purpose: To determine which number is larger and smaller.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    bool truVlue, falVlue;
    int a=10, y=5;
    
    //Input or initialize values Here
    truVlue= a>y;
    falVlue= a<y;
    
    
    
    //Process/Calculations Here
    cout<<"True is" <<truVlue<<endl;
    cout<<"False is" <<falVlue<<endl;
    
    
    //Output Located Here
    
    //Exit
    return 0;
}

