/* 
 * File:   main.cpp
 * Author: Juan M. Rodriguez
 * Created on October 3, 2017, 11:26 AM
 * Purpose: Display which runner came in first, second, and third 
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float Saul,
            Rick,
            Morty;
    
    //Input or initialize values Here
    Saul= 6.5;
    Rick= 8.5;
    Morty= 7.0;
    
    
    
    //Process/Calculations Here
    
    
    
    //Output Located Here
    cout<<"In first place runner Saul, With a time of "<<Saul<<"mins"<<endl;
    cout<<"In second place runner Morty, With a time of "<<Morty<<"mins"<<endl;
    cout<<"In third place runner Rick, With a time of "<<Rick<<"mins"<<endl;

    //Exit
    return 0;
}

