/* 
 * File:   main.cpp
 * Author: Juan M.Rodriguez
 * Created on October 7, 2017, 7:00 PM
 * Purpose:  Magic date
 */

//System Libraries Here
#include <iostream>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here

int main(int argc, char** argv) {
    //Declare all Variables Here
    short int month;
    short int day;
    short int year;
    
    
    //Input or initialize values Here
    
    
           
       


    //Process/Calculations Here
   
    
            
                    
    
    

    //Output Located Here
    cout<<"Enter a month in numeric form"<<endl;
    cin>>month;
    cout<<"Enter a day from that month"<<endl;
    cin>>day;
    cout<<"Enter a two digit year"<<endl;
    cin>>year;
      
    //If statement
    if (month && day == year){
        cout<<"Your date is a magic date"<<endl;
        
    }
         
    else if (month && day == year){
        cout<<"sorry your date is not magical"<<endl;
    }  
    
    //Exit
    return 0;
}

