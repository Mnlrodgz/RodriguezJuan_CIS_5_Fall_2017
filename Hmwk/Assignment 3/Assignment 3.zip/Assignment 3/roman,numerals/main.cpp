/* 
 * File:   main.cpp
 * Author: Juan M.Rodriguez
 * Created on October 8th, 2017, 6:00 PM
 * Purpose:Converting to Roman Numerals  
 */

//System Libraries Here
#include <iostream>
#include <stdlib.h>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const int thsnds=1000;
const int hndrds= 100;
const int tens= 10;
const int ones= 1;
//Function Prototypes Here

//Program Execution Begins Here

int main(int argc, char** argv){
    //Declare all Variables Here
    unsigned char nThsnds,nHndrds,nTens,nOnes;
    unsigned short number;
            
    
    
    //Input or initialize values Here
    cout<<"This program will convert regular numbers into Roman Numerals"<<endl;
    cout<<"Type in a number between 1000-3000"<<endl;
    cin>>number;
    if(!(number>=1000&&number<=3000))
    { 
        cout<<"The number you typed ="<<number<<endl;
        cout<<"This is an invalids number, try again!"<<endl;
    }
            
    //Mapping inputs
    nThsnds=number/thsnds;
    number%=thsnds;
    nHndrds=number/hndrds;
    number%=hndrds;
    nTens=number/tens;
    number%=tens;
    nOnes=number;//same as number/ones;
    cout<<static_cast<int>(nThsnds)<<""<<static_cast<int>(nHndrds)
            <<""<<static_cast<int>(nTens)<<""<<static_cast<int>(nOnes)<<endl;
    
    //Display/Output all pertinent variables
    //number of 1000's
    switch(nThsnds){
        case 3:cout<<"M";
        case 2:cout<<"M";
        case 1:cout<<"M";
    }
            
      //Display number of 100's
    switch(nHndrds){
        case 9:cout<<"CM";break;
        case 8:cout<<"DCCC";break;
        case 7:cout<<"DCC";break;
        case 6:cout<<"DC";break;
        case 5:cout<<"D";break;
        case 4:cout<<"CD";break;
        case 3:cout<<"C";
        case 2:cout<<"C";
        case 1:cout<<"C";
    }
        
     //Display number of 10's
    switch(nTens){   case 9:cout<<"XC";break;
        case 8:cout<<"LXXX";break;
        case 7:cout<<"LXX";break;
        case 6:cout<<"LX";break;
        case 5:cout<<"L";break;
        case 4:cout<<"XL";break;
        case 3:cout<<"X";
        case 2:cout<<"X";
        case 1:cout<<"X";
        
    }
       //Display number of 1's
    switch(nOnes){
        case 9:cout<<"IX";break;
        case 8:cout<<"VIII";break;
        case 7:cout<<"V||";break;
        case 6:cout<<"VI";break;
        case 5:cout<<"V";break;
        case 4:cout<<"IV";break;
        case 3:cout<<"I";
        case 2:cout<<"I";
        case 1:cout<<"I";
    }



   
    
            
                    
    

    
         
         
         
    
    //Exit
    return 0;

}
