/* 
 * File:   main.cpp
 * Author: Juan M.Rodriguez
 * Created on September 15, 2017, 11:12 AM
 * Purpose: Area of a triangle 
 */

//System Libraries Here
#include <iostream>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here

int main(int argc, char** argv) {
    //Declare all Variables Here
    float a1,//height of first rectangle
            b1,//width of first rectangle 
            ab1,//area of first rectangle 
            a2,//height of second rectangle
            b2,//width of second rectangle 
            ab2,//area of second rectangle
            lngth;//length
    
    //Input or initialize values Here
    a1=5;
    b1=10;
    a2=4;
    b2=6;
    
           
       


    //Process/Calculations Here
    ab1=a1*b1;
    ab2=a1*b2;
    
            
                    
    
    

    //Output Located Here
    cout<<"Insert the length and width of two rectangle"<<endl;
    cin>>lngth;
    cout<<"area of rectangle one= "<<ab1<<endl;
    cout<<"Insert the length and width of second rectangle"<<endl;
    cin>>lngth;
    cout<<"area of rectangle two= "<<ab2<<endl;
    
    
         
         
         
    
    //Exit
    return 0;
}

