/* 
 * File:   main.cpp
 * Author: Juan M. Rodriguez
 * Created on September 26, 2017, 11:13 AM
 * Purpose:  To Create the truth table 
 */

//System Libraries Here
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    bool x,y;//Boolean expressions 
    
    //Display the Head
    cout
    <<"X Y !X !Y X||Y X&&Y X^Y X^Y^Y X^Y^X"
    <<"!(X||Y) !X&&!Y !(X&&Y) !X||!Y"<<endl;
    
    //Input or initialize For The First Row
    x=true;
    y=true;
    //Display the first Row
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x||y?'T':'F')<<"  ";
    cout<<(x&&y?'T':'F')<<"    " ;
    cout<<(x^y?'T':'F')<<"      ";
    cout<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"     ";
    cout<<(x||y?'T':'F')<<"     ";
    cout<<(!x&&!y?'T':'F')<<"     ";
    cout<<(!x&&y?'T':'F')<<"     ";
    cout<<(!x||!y?'T':'F')<<"     ";
    cout<<endl;
    //Input or initialize For The second Row
    x=true;
    y=false;
    //Display the second Row
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x||y?'T':'F')<<"  ";
    cout<<(x&&y?'T':'F')<<"    " ;
    cout<<(x^y?'T':'F')<<"      ";
    cout<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"     ";
    cout<<(x||y?'T':'F')<<"     ";
    cout<<(!x&&!y?'T':'F')<<"     ";
    cout<<(!x&&y?'T':'F')<<"     ";
    cout<<(!x||!y?'T':'F')<<"     ";
    cout<<endl;
    //Input or initialize For The third Row
    x=false;
    y=true;
    //Display the 3rd Row
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x||y?'T':'F')<<"  ";
    cout<<(x&&y?'T':'F')<<"    " ;
    cout<<(x^y?'T':'F')<<"      ";
    cout<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"     ";
    cout<<(x||y?'T':'F')<<"     ";
    cout<<(!x&&!y?'T':'F')<<"     ";
    cout<<(!x&&y?'T':'F')<<"     ";
    cout<<(!x||!y?'T':'F')<<"     ";
    cout<<endl;
    //Input or initialize For The Fourth Row
    x=false;
    y=false;
    //Display the fourth Row
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x||y?'T':'F')<<"  ";
    cout<<(x&&y?'T':'F')<<"    " ;
    cout<<(x^y?'T':'F')<<"      ";
    cout<<(x^y^y?'T':'F')<<"     ";
    cout<<(x^y^x?'T':'F')<<"     ";
    cout<<(x||y?'T':'F')<<"     ";
    cout<<(!x&&!y?'T':'F')<<"     ";
    cout<<(!x&&y?'T':'F')<<"     ";
    cout<<(!x||!y?'T':'F')<<"     ";
    cout<<endl;
    //Process/Calculations Here
    
    //Output Located Here
   
    //Exit
    return 0;
}

